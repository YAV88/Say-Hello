import colorama
from colorama import Fore
colorama.init()
def main():
    print(Fore.RED + "Hello!")

if __name__ == '__main__':
    main()